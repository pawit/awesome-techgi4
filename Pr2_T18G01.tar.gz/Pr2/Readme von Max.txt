Wie man's ausführt:

1. Im myWSServer Ordner "ant mywsgen" und dann "ant run" machen.
2. Im myWSClient Ordner ".mywsimport.sh" und dann "ant run" aufrufen.